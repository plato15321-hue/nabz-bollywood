import os
import asyncio
import aiohttp
import json
from datetime import datetime
from telegram import Bot
from bs4 import BeautifulSoup
import google.generativeai as genai

BOT_TOKEN = os.environ.get("BOT_TOKEN")
CHANNEL_ID = "@nabz_bollywood"
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")

genai.configure(api_key=GEMINI_API_KEY)
model = genai.GenerativeModel('gemini-1.5-flash')

SENT_FILE = "sent_news.json"

def load_sent():
    try:
        with open(SENT_FILE) as f:
            return set(json.load(f))
    except:
        return set()

def save_sent(ids):
    with open(SENT_FILE, 'w') as f:
        json.dump(list(ids)[-300:], f)

async def translate_news(text):
    try:
        prompt = f"""این خبر بالیوودی رو به فارسی روان، جذاب و کامل ترجمه کن.
قوانین مهم:
- اسم فیلم‌ها: فارسی (انگلیسی) مثلاً: دیلواله (Dilwale)
- اسم بازیگرا: فارسی بنویس
- لحن: صمیمی و جذاب
- در آخر هشتگ‌های مرتبط اضافه کن (فارسی + انگلیسی)
- حتماً اسم بازیگرا و فیلم‌ها هشتگ بشن

فرمت خروجی:
🎬 [عنوان جذاب فارسی]

[متن خبر فارسی - حداقل ۳ پاراگراف]

📌 منبع: نبض بالیوود

#هشتگ۱ #هشتگ۲ #هشتگ۳ #بالیوود #Bollywood #سینمای_هند

خبر انگلیسی:
{text}"""
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        print(f"Gemini error: {e}")
        return None

async def get_news():
    news = []
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0"}
    
    async with aiohttp.ClientSession() as session:
        # Bollywood Hungama RSS
        try:
            async with session.get("https://www.bollywoodhungama.com/rss/news.xml", headers=headers, timeout=15) as r:
                if r.status == 200:
                    soup = BeautifulSoup(await r.text(), 'xml')
                    for item in soup.find_all('item')[:3]:
                        t = item.find('title')
                        d = item.find('description')
                        if t and d:
                            news.append({"title": t.text, "desc": d.text[:600], "src": "BH"})
        except Exception as e:
            print(f"BH error: {e}")

        # Pinkvilla RSS
        try:
            async with session.get("https://www.pinkvilla.com/rss.xml", headers=headers, timeout=15) as r:
                if r.status == 200:
                    soup = BeautifulSoup(await r.text(), 'xml')
                    for item in soup.find_all('item')[:3]:
                        t = item.find('title')
                        d = item.find('description') 
                        if t and d:
                            kw = ['bollywood','film','actor','actress','movie','khan','kapoor','kumar','sharma']
                            if any(k in t.text.lower() for k in kw):
                                news.append({"title": t.text, "desc": d.text[:600], "src": "PV"})
        except Exception as e:
            print(f"PV error: {e}")

        # Filmfare RSS
        try:
            async with session.get("https://www.filmfare.com/rss/news.xml", headers=headers, timeout=15) as r:
                if r.status == 200:
                    soup = BeautifulSoup(await r.text(), 'xml')
                    for item in soup.find_all('item')[:3]:
                        t = item.find('title')
                        d = item.find('description')
                        if t and d:
                            news.append({"title": t.text, "desc": d.text[:600], "src": "FF"})
        except Exception as e:
            print(f"FF error: {e}")

    return news

async def main():
    sent = load_sent()
    news = await get_news()
    bot = Bot(token=BOT_TOKEN)
    
    new_count = 0
    for item in news:
        news_id = str(hash(item['title']))
        if news_id in sent:
            continue
        
        raw = f"{item['title']}\n\n{item['desc']}"
        formatted = await translate_news(raw)
        
        if not formatted:
            continue
            
        try:
            await bot.send_message(
                chat_id=CHANNEL_ID,
                text=formatted[:4096],
            )
            sent.add(news_id)
            new_count += 1
            await asyncio.sleep(5)
        except Exception as e:
            print(f"Send error: {e}")
    
    save_sent(sent)
    print(f"✅ {new_count} خبر جدید ارسال شد - {datetime.now().strftime('%H:%M')}")

if __name__ == "__main__":
    asyncio.run(main())
