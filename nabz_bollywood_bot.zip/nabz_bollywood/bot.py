import os
import asyncio
import aiohttp
import json
import re
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes
from telegram.constants import ParseMode
import google.generativeai as genai
from bs4 import BeautifulSoup

# ============ CONFIG ============
BOT_TOKEN = os.environ.get("BOT_TOKEN")
CHANNEL_ID = "@nabz_bollywood"
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")

genai.configure(api_key=GEMINI_API_KEY)
model = genai.GenerativeModel('gemini-1.5-flash')

# ============ GENRES ============
GENRES = {
    "romantic": "❤️ عاشقانه",
    "action": "💥 اکشن",
    "comedy": "😂 کمدی",
    "musical": "🎵 موزیکال",
    "drama": "🎭 درام",
    "thriller": "😱 هیجانی",
    "family": "👨‍👩‍👧 خانوادگی",
    "biography": "📖 بیوگرافی"
}

# ============ SOURCES ============
SOURCES = [
    "https://www.bollywoodhungama.com/news/",
    "https://www.pinkvilla.com/entertainment/bollywood",
    "https://www.filmfare.com/news/bollywood",
]

# ============ GEMINI HELPERS ============
async def translate_and_format(text: str, context_type: str = "news") -> str:
    try:
        if context_type == "news":
            prompt = f"""این خبر بالیوودی رو به فارسی روان و جذاب ترجمه کن.
اسم فیلم‌ها رو هم فارسی هم انگلیسی بنویس مثلاً: دیلواله (Dilwale)
اسم بازیگرا رو فارسی بنویس.
در آخر هشتگ‌های مرتبط فارسی و انگلیسی اضافه کن.
فرمت خروجی:
🎬 [عنوان جذاب]

[متن خبر فارسی]

[هشتگ‌ها]

خبر: {text}"""
        elif context_type == "biography":
            prompt = f"""بیوگرافی این بازیگر بالیوودی رو به فارسی کامل و جذاب بنویس.
شامل: تولد، خانواده، فیلم‌های مشهور، جوایز، زندگی شخصی
فرمت:
⭐ نام فارسی (نام انگلیسی)
📅 تولد:
🎬 مشهور به:
🏆 جوایز:
❤️ زندگی شخصی:
🎭 فیلم‌های برتر:

اطلاعات: {text}"""
        elif context_type == "movie":
            prompt = f"""اطلاعات این فیلم بالیوودی رو به فارسی جذاب بنویس.
فرمت:
🎬 نام فارسی (نام انگلیسی)
⭐ امتیاز:
📅 سال اکران:
💰 فروش:
🎭 بازیگران:
📝 خلاصه داستان:
#هشتگ‌های_مرتبط

اطلاعات: {text}"""

        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        return text

async def generate_hashtags(text: str) -> str:
    try:
        prompt = f"""از این متن، هشتگ‌های مرتبط فارسی و انگلیسی استخراج کن.
شامل: اسم بازیگرا، اسم فیلم‌ها، ژانر، کلمات کلیدی
فقط هشتگ‌ها رو بده، بدون توضیح اضافه.
مثال: #شاهرخ_خان #SRK #بالیوود #Bollywood
متن: {text}"""
        response = model.generate_content(prompt)
        return response.text
    except:
        return "#بالیوود #Bollywood #سینمای_هند"

# ============ SCRAPING ============
async def scrape_bollywood_news() -> list:
    news_list = []
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
    
    async with aiohttp.ClientSession() as session:
        # Bollywood Hungama RSS
        try:
            async with session.get("https://www.bollywoodhungama.com/rss/news.xml", headers=headers, timeout=10) as resp:
                if resp.status == 200:
                    text = await resp.text()
                    soup = BeautifulSoup(text, 'xml')
                    items = soup.find_all('item')[:5]
                    for item in items:
                        title = item.find('title')
                        desc = item.find('description')
                        if title and desc:
                            news_list.append({
                                "title": title.text,
                                "description": desc.text[:500],
                                "source": "Bollywood Hungama"
                            })
        except:
            pass

        # Pinkvilla RSS
        try:
            async with session.get("https://www.pinkvilla.com/rss.xml", headers=headers, timeout=10) as resp:
                if resp.status == 200:
                    text = await resp.text()
                    soup = BeautifulSoup(text, 'xml')
                    items = soup.find_all('item')[:5]
                    for item in items:
                        title = item.find('title')
                        desc = item.find('description')
                        if title and desc:
                            content = desc.text if desc else ""
                            if any(k in title.text.lower() for k in ['bollywood','film','actor','actress','movie','khan','kapoor','kumar']):
                                news_list.append({
                                    "title": title.text,
                                    "description": content[:500],
                                    "source": "Pinkvilla"
                                })
        except:
            pass

        # IMDb Bollywood
        try:
            async with session.get("https://www.imdb.com/news/top?ref_=nv_nw_tp", headers=headers, timeout=10) as resp:
                if resp.status == 200:
                    text = await resp.text()
                    soup = BeautifulSoup(text, 'html.parser')
                    articles = soup.find_all('article', limit=3)
                    for art in articles:
                        h = art.find(['h1','h2','h3'])
                        p = art.find('p')
                        if h and p:
                            news_list.append({
                                "title": h.text.strip(),
                                "description": p.text.strip()[:500],
                                "source": "IMDb"
                            })
        except:
            pass

    return news_list

async def get_actor_info(name: str) -> str:
    try:
        async with aiohttp.ClientSession() as session:
            headers = {"User-Agent": "Mozilla/5.0"}
            url = f"https://www.imdb.com/find?q={name.replace(' ','+')}&s=nm"
            async with session.get(url, headers=headers, timeout=10) as resp:
                text = await resp.text()
                soup = BeautifulSoup(text, 'html.parser')
                result = soup.find('td', class_='result_text')
                if result:
                    return f"بازیگر: {name}\n{result.text}"
                return f"بازیگر: {name}"
    except:
        return f"بازیگر: {name}"

async def get_movie_info(title: str) -> str:
    try:
        async with aiohttp.ClientSession() as session:
            headers = {"User-Agent": "Mozilla/5.0"}
            url = f"https://www.imdb.com/find?q={title.replace(' ','+')}&s=tt"
            async with session.get(url, headers=headers, timeout=10) as resp:
                text = await resp.text()
                soup = BeautifulSoup(text, 'html.parser')
                result = soup.find('td', class_='result_text')
                if result:
                    return f"فیلم: {title}\n{result.text}"
                return f"فیلم: {title}"
    except:
        return f"فیلم: {title}"

# ============ SEND TO CHANNEL ============
async def send_news_to_channel(app: Application):
    news = await scrape_bollywood_news()
    sent = load_sent_ids()
    
    for item in news:
        news_id = hash(item['title'])
        if news_id in sent:
            continue
        
        raw = f"{item['title']}\n\n{item['description']}"
        formatted = await translate_and_format(raw, "news")
        
        try:
            await app.bot.send_message(
                chat_id=CHANNEL_ID,
                text=formatted,
                parse_mode=ParseMode.MARKDOWN
            )
            sent.add(news_id)
            save_sent_ids(sent)
            await asyncio.sleep(3)
        except Exception as e:
            print(f"Error sending: {e}")

def load_sent_ids():
    try:
        with open('sent_ids.json', 'r') as f:
            return set(json.load(f))
    except:
        return set()

def save_sent_ids(ids):
    with open('sent_ids.json', 'w') as f:
        json.dump(list(ids)[-500:], f)

# ============ BOT HANDLERS ============
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    
    # Force Join Check
    try:
        member = await context.bot.get_chat_member(CHANNEL_ID, user.id)
        if member.status in ['left', 'kicked']:
            keyboard = [[InlineKeyboardButton("📢 عضویت در کانال نبض بالیوود", url=f"https://t.me/nabz_bollywood")],
                       [InlineKeyboardButton("✅ عضو شدم", callback_data="check_join")]]
            await update.message.reply_text(
                "🎬 برای استفاده از ربات، اول عضو کانال نبض بالیوود بشو!",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
            return
    except:
        pass

    await show_main_menu(update, context)

async def show_main_menu(update, context):
    keyboard = [
        [InlineKeyboardButton("🔍 جستجوی بازیگر", callback_data="search_actor"),
         InlineKeyboardButton("🎬 جستجوی فیلم", callback_data="search_movie")],
        [InlineKeyboardButton("🎭 فیلم‌ها بر اساس ژانر", callback_data="genres")],
        [InlineKeyboardButton("📰 آخرین اخبار", callback_data="latest_news"),
         InlineKeyboardButton("⭐ پرفروش‌ترین‌ها", callback_data="top_movies")],
        [InlineKeyboardButton("📅 اکران این هفته", callback_data="upcoming")],
    ]
    
    text = """🎬 *به نبض بالیوود خوش اومدی!*

من همه چیز درباره بالیوود بلدم:
• اخبار داغ بازیگرا
• اطلاعات فیلم‌ها
• بیوگرافی ستاره‌ها
• میزان فروش فیلم‌ها

یه گزینه انتخاب کن 👇"""

    if update.callback_query:
        await update.callback_query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode=ParseMode.MARKDOWN)
    else:
        await update.message.reply_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode=ParseMode.MARKDOWN)

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data

    # Check join
    if data == "check_join":
        try:
            member = await context.bot.get_chat_member(CHANNEL_ID, query.from_user.id)
            if member.status in ['left', 'kicked']:
                await query.answer("هنوز عضو نشدی! 😅", show_alert=True)
                return
            await show_main_menu(update, context)
        except:
            await show_main_menu(update, context)
        return

    if data == "genres":
        keyboard = []
        row = []
        for key, val in GENRES.items():
            row.append(InlineKeyboardButton(val, callback_data=f"genre_{key}"))
            if len(row) == 2:
                keyboard.append(row)
                row = []
        if row:
            keyboard.append(row)
        keyboard.append([InlineKeyboardButton("🔙 برگشت", callback_data="main_menu")])
        await query.edit_message_text("🎭 *ژانر مورد علاقه‌ات رو انتخاب کن:*", reply_markup=InlineKeyboardMarkup(keyboard), parse_mode=ParseMode.MARKDOWN)

    elif data.startswith("genre_"):
        genre = data.replace("genre_", "")
        genre_name = GENRES.get(genre, genre)
        
        movies = await get_movies_by_genre(genre)
        keyboard = []
        for movie in movies[:8]:
            keyboard.append([InlineKeyboardButton(f"🎬 {movie['fa']} ({movie['en']})", callback_data=f"movie_{movie['en'][:30]}")])
        keyboard.append([InlineKeyboardButton("🔙 برگشت", callback_data="genres")])
        
        await query.edit_message_text(
            f"🎬 *فیلم‌های {genre_name}:*",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode=ParseMode.MARKDOWN
        )

    elif data.startswith("movie_"):
        movie_name = data.replace("movie_", "")
        await query.edit_message_text("⏳ در حال دریافت اطلاعات فیلم...")
        info = await get_movie_info(movie_name)
        formatted = await translate_and_format(info, "movie")
        keyboard = [[InlineKeyboardButton("🔙 برگشت", callback_data="genres")]]
        await query.edit_message_text(formatted, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode=ParseMode.MARKDOWN)

    elif data == "search_actor":
        context.user_data['waiting_for'] = 'actor'
        keyboard = [[InlineKeyboardButton("🔙 برگشت", callback_data="main_menu")]]
        await query.edit_message_text(
            "🔍 *اسم بازیگر رو بنویس:*\nمثلاً: Shah Rukh Khan یا شاهرخ خان",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode=ParseMode.MARKDOWN
        )

    elif data == "search_movie":
        context.user_data['waiting_for'] = 'movie'
        keyboard = [[InlineKeyboardButton("🔙 برگشت", callback_data="main_menu")]]
        await query.edit_message_text(
            "🔍 *اسم فیلم رو بنویس:*\nمثلاً: Dilwale یا دیلواله",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode=ParseMode.MARKDOWN
        )

    elif data == "latest_news":
        await query.edit_message_text("⏳ در حال دریافت آخرین اخبار...")
        news = await scrape_bollywood_news()
        if not news:
            await query.edit_message_text("❌ خبری پیدا نشد. بعداً دوباره امتحان کن.")
            return
        item = news[0]
        raw = f"{item['title']}\n\n{item['description']}"
        formatted = await translate_and_format(raw, "news")
        keyboard = [[InlineKeyboardButton("🔙 برگشت", callback_data="main_menu")]]
        await query.edit_message_text(formatted[:4000], reply_markup=InlineKeyboardMarkup(keyboard), parse_mode=ParseMode.MARKDOWN)

    elif data == "top_movies":
        text = """💰 *پرفروش‌ترین فیلم‌های بالیوود ۲۰۲۴:*

🥇 کلکی (Kalki 2898 AD) - ₹۱۰۰۰+ کرور
🥈 استرا (Stree 2) - ₹۶۰۰+ کرور  
🥉 سینگهام اگین (Singham Again) - ₹۳۰۰+ کرور
4️⃣ میدی (Maidaan) - ₹۱۵۰+ کرور
5️⃣ کروانا (Crew) - ₹۱۰۰+ کرور

#پرفروش_ترین #بالیوود #Bollywood #BoxOffice"""
        keyboard = [[InlineKeyboardButton("🔙 برگشت", callback_data="main_menu")]]
        await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode=ParseMode.MARKDOWN)

    elif data == "upcoming":
        text = """📅 *اکران‌های پیش رو بالیوود:*

🎬 پوشپا ۲ (Pushpa 2) - دسامبر ۲۰۲۴
🎬 بابی جاسوس (Baby John) - دسامبر ۲۰۲۴
🎬 اسکای فورس (Sky Force) - ژانویه ۲۰۲۵
🎬 چاوا (Chhaava) - فوریه ۲۰۲۵
🎬 سینی والا (Sikandar) - مارس ۲۰۲۵

#اکران_جدید #بالیوود #Bollywood #فیلم_هندی"""
        keyboard = [[InlineKeyboardButton("🔙 برگشت", callback_data="main_menu")]]
        await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode=ParseMode.MARKDOWN)

    elif data == "main_menu":
        await show_main_menu(update, context)

async def get_movies_by_genre(genre: str) -> list:
    genre_movies = {
        "romantic": [
            {"fa": "دیلواله", "en": "Dilwale Dulhania Le Jayenge"},
            {"fa": "کبیر سینگ", "en": "Kabir Singh"},
            {"fa": "راهول", "en": "Devdas"},
            {"fa": "جب وی مت", "en": "Jab We Met"},
            {"fa": "تام پیشه", "en": "Tamasha"},
            {"fa": "آشیقانه", "en": "Aashiqui 2"},
        ],
        "action": [
            {"fa": "دبانگ", "en": "Dabangg"},
            {"fa": "وار", "en": "War"},
            {"fa": "پاتان", "en": "Pathaan"},
            {"fa": "تایگر ۳", "en": "Tiger 3"},
            {"fa": "سینگهام", "en": "Singham"},
            {"fa": "بجرنگی بایجان", "en": "Bajrangi Bhaijaan"},
        ],
        "comedy": [
            {"fa": "هره فری", "en": "Hera Pheri"},
            {"fa": "آند ملاقات", "en": "Andaz Apna Apna"},
            {"fa": "گلمال", "en": "Golmaal"},
            {"fa": "تو ایک میلا", "en": "3 Idiots"},
            {"fa": "دم لگا که هایشا", "en": "Dum Laga Ke Haisha"},
        ],
        "musical": [
            {"fa": "دیل سه", "en": "Dil Se"},
            {"fa": "لگان", "en": "Lagaan"},
            {"fa": "دیوداس", "en": "Devdas 2002"},
            {"fa": "بلک", "en": "Black"},
            {"fa": "گلزار", "en": "Gulzar"},
        ],
        "drama": [
            {"fa": "تارا زمین پر", "en": "Taare Zameen Par"},
            {"fa": "بلک", "en": "Black"},
            {"fa": "بارفی", "en": "Barfi"},
            {"fa": "قریب قریب سینگل", "en": "Qarib Qarib Singlle"},
        ],
        "thriller": [
            {"fa": "دریشیام", "en": "Drishyam"},
            {"fa": "آندها دون", "en": "Andhadhun"},
            {"fa": "کاهانی", "en": "Kahaani"},
            {"fa": "تالوار", "en": "Talvar"},
        ],
        "family": [
            {"fa": "بجرنگی بایجان", "en": "Bajrangi Bhaijaan"},
            {"fa": "کوچ‌کوچ هوتا هی", "en": "Kuch Kuch Hota Hai"},
            {"fa": "کبهی کوشی کبهی غام", "en": "Kabhi Khushi Kabhie Gham"},
        ],
        "biography": [
            {"fa": "بایوپیک ماری کوم", "en": "Mary Kom"},
            {"fa": "دانگال", "en": "Dangal"},
            {"fa": "ام اس دونی", "en": "MS Dhoni The Untold Story"},
            {"fa": "سانجو", "en": "Sanju"},
        ],
    }
    return genre_movies.get(genre, [])

async def message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    waiting = context.user_data.get('waiting_for')

    if waiting == 'actor':
        context.user_data['waiting_for'] = None
        await update.message.reply_text("⏳ در حال جستجو...")
        info = await get_actor_info(text)
        formatted = await translate_and_format(info, "biography")
        await update.message.reply_text(formatted[:4000], parse_mode=ParseMode.MARKDOWN)

    elif waiting == 'movie':
        context.user_data['waiting_for'] = None
        await update.message.reply_text("⏳ در حال جستجو...")
        info = await get_movie_info(text)
        formatted = await translate_and_format(info, "movie")
        await update.message.reply_text(formatted[:4000], parse_mode=ParseMode.MARKDOWN)

    else:
        # Smart AI reply
        try:
            prompt = f"""تو دستیار ربات بالیوود فارسی هستی. به این پیام کاربر جواب بده.
اگه درباره بازیگر یا فیلم هندی پرسیده، اطلاعات کامل بده.
فارسی جواب بده. جواب کوتاه و مفید.
پیام: {text}"""
            response = model.generate_content(prompt)
            await update.message.reply_text(response.text[:4000])
        except:
            await update.message.reply_text("از منوی اصلی استفاده کن 😊 /start")

async def news_job(context: ContextTypes.DEFAULT_TYPE):
    await send_news_to_channel(context.application)

# ============ MAIN ============
def main():
    app = Application.builder().token(BOT_TOKEN).build()
    
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button_handler))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, message_handler))
    
    # Send news every 30 minutes
    app.job_queue.run_repeating(news_job, interval=1800, first=10)
    
    print("🤖 ربات نبض بالیوود شروع به کار کرد!")
    app.run_polling()

if __name__ == "__main__":
    main()
