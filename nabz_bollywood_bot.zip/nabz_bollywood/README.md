# 🎬 ربات نبض بالیوود

## راه‌اندازی

### ۱. GitHub Secrets
برو به Settings > Secrets > Actions و اضافه کن:
- `BOT_TOKEN` — توکن ربات تلگرام
- `GEMINI_API_KEY` — کلید Gemini

### ۲. ارسال خودکار کانال (GitHub Actions)
- فایل‌ها رو تو GitHub آپلود کن
- Actions خودکار هر ۵ دقیقه اجرا میشه
- اخبار جدید تو کانال @nabz_bollywood پست میشه

### ۳. ربات تعاملی (Railway)
- برو به railway.app
- با GitHub لاگین کن
- New Project > Deploy from GitHub
- همین repo رو انتخاب کن
- Environment Variables:
  - BOT_TOKEN
  - GEMINI_API_KEY

## قابلیت‌ها
- ✅ اخبار خودکار هر ۵ دقیقه
- ✅ ترجمه فارسی با Gemini
- ✅ هشتگ خودکار
- ✅ اسم فارسی + انگلیسی
- ✅ جستجوی بازیگر
- ✅ جستجوی فیلم
- ✅ دکمه‌های ژانر
- ✅ Force Join کانال
